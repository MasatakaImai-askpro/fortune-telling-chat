import React, { useEffect, useRef, useState } from "react";
import { getCookie } from "./utils/cookies";
import ReactDOM from "react-dom/client";
import "./index.css";


type User = { id: number; username: string; email?: string };

// 環境変数。Viteなら `.env` に VITE_API_URL を入れておく(例: http://127.0.0.1:8000/api)
// もしくは Vite の proxy を使うなら "/api" にしてOK
const API_BASE = (import.meta.env.VITE_API_URL as string) ?? "/api";
const csrftoken = getCookie("csrftoken");

export default function AdminApp() {
    const [activeTab, setActiveTab] = useState("dashboard");

    // 設定タブで使う状態
    const [users, setUsers] = useState<User[]>([]);
    const [loadingUsers, setLoadingUsers] = useState(false);
    const [usersError, setUsersError] = useState<string | null>(null);
    const usersLoadedOnce = useRef(false); // 二重フェッチ防止
    const [message, setMessage] = useState<string | null>(null);

    // タブ変更で「設定」になったらユーザー一覧を取得
    useEffect(() => {
        if (activeTab !== "content" || usersLoadedOnce.current) return;

        const ctrl = new AbortController();
        (async () => {
            try {
            setLoadingUsers(true);
            const res = await fetch(`${API_BASE}/users/`, { signal: ctrl.signal });
            if (!res.ok) throw new Error(`status ${res.status}`);
            const data = await res.json();
            // Djangoが {"message": "..."} を返すだけなので message に格納
            if (data.message) setMessage(data.message);
            else setUsers(data); // 将来的にユーザー一覧を返す場合に備えて
            usersLoadedOnce.current = true;
            } catch (e: any) {
            if (e.name !== "AbortError") setUsersError(e.message);
            } finally {
            setLoadingUsers(false);
            }
        })();

        return () => ctrl.abort();
        }, [activeTab]);

  // -----------------------------
  // 顧客取得
  // -----------------------------
    type Customer = {
        id: string;
        name: string;
        email?: string;
    };

    type CustomerPageResp = {
        count: number;
        results: Customer[];
    };

    const [customers, setCustomers] = useState<Customer[]>([]);
    const [customersTotal, setCustomersTotal] = useState(0);
    const [customersPage, setCustomersPage] = useState(1);
    const [loadingCustomers, setLoadingCustomers] = useState(false);

    // 検索（ページ内フィルタ）
    const [customerQuery, setCustomerQuery] = useState("");

    // モーダル：ポイント付与
    const [grantOpen, setGrantOpen] = useState(false);
    const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
    const [grantPoints, setGrantPoints] = useState<number>(100);
    const [grantNote, setGrantNote] = useState<string>("");
    const [granting, setGranting] = useState(false);
    const [grantError, setGrantError] = useState<string | null>(null);
    const [grantSuccess, setGrantSuccess] = useState<string | null>(null);

    const pageSize = 20;
    const totalPages = Math.max(1, Math.ceil(customersTotal / pageSize));

    useEffect(() => {
        if (activeTab !== "customers") return;

        const ctrl = new AbortController();
        
        (async () => {
            try {
                setLoadingCustomers(true);
                const res = await fetch (
                    `${API_BASE}/get_querents_list/?page=${customersPage}&page_size=20`,
                    { signal: ctrl.signal }
                );
                if (!res.ok) throw new Error (`status${res.status}`);

                const data: CustomerPageResp = await res.json();
                setCustomers(data.results)
                setCustomersTotal(data.count)
            } catch (e:any) {
                if (e.name !== "AbortError") {
                    console.error(e);
                }
            } finally {
                setLoadingCustomers(false);
            }
        })();
        return () => ctrl.abort();
    }, [activeTab, customersPage]);

    const filteredCustomers = (() => {
        const q = customerQuery.trim().toLowerCase();
        if (!q) return customers;
        return customers.filter((c) => {
            return (
                c.id.toLowerCase().includes(q) ||
                c.name.toLowerCase().includes(q) ||
                (c.email?.toLowerCase().includes(q) ?? false)
            );
        });
    })();

    const openGrantModal = (c: Customer) => {
        setSelectedCustomer(c);
        setGrantPoints(100);
        setGrantNote("");
        setGrantError(null);
        setGrantSuccess(null);
        setGrantOpen(true);
    };

    const closeGrantModal = () => {
        if (granting) return;
        setGrantOpen(false);
        setSelectedCustomer(null);
    };

    const submitGrantPoints = async () => {
        if (!selectedCustomer) return;

        // バリデーション
        if (!Number.isFinite(grantPoints) || grantPoints <= 0) {
            setGrantError("ポイントは1以上の数値で入力してください。");
            return;
        }

        setGrantError(null);
        setGrantSuccess(null);
        setGranting(true);

        try {
            // ★あなたの実APIに合わせて変更する箇所
            const res = await fetch(`${API_BASE}/grant_points/`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    customer_id: selectedCustomer.id,
                    points: grantPoints,
                    note: grantNote?.trim() ? grantNote.trim() : undefined,
                }),
            });

            if (!res.ok) {
                const text = await res.text().catch(() => "");
                throw new Error(`status ${res.status} ${text}`);
            }

            setGrantSuccess("ポイントを付与しました。");
            // すぐ閉じたい場合はここで closeGrantModal(); にしてOK
            setTimeout(() => {
                closeGrantModal();
            }, 600);
        } catch (e: any) {
            console.error(e);
            setGrantError("ポイント付与に失敗しました。APIレスポンスを確認してください。");
        } finally {
            setGranting(false);
        }
    };

    function Modal({
        open,
        title,
        children,
        onClose,
    }: {
        open: boolean;
        title: string;
        children: React.ReactNode;
        onClose: () => void;
    }) {
        if (!open) return null;

        return (
            <div
                className="fixed inset-0 z-50"
                role="dialog"
                aria-modal="true"
                onMouseDown={(e) => {
                    // 背景クリックで閉じる
                    if (e.target === e.currentTarget) onClose();
                }}
            >
                <div className="absolute inset-0 bg-black/60" />
                <div className="absolute inset-0 flex items-center justify-center p-4">
                    <div className="w-full max-w-lg rounded-2xl bg-[#0d1a33] border border-white/10 shadow-xl">
                        <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
                            <div className="text-sm font-semibold text-white">{title}</div>
                            <button
                                className="text-white/70 hover:text-white text-sm"
                                onClick={onClose}
                                aria-label="Close"
                                disabled={granting}
                            >
                                ✕
                            </button>
                        </div>
                        <div className="p-4">{children}</div>
                    </div>
                </div>
            </div>
        );
    }

    // -----------------------------
  // 占い師取得
  // -----------------------------

    type Advisor = {
        id: string;
        name: string;
        rank: string;
    };

    type AdvisorPageResp = {
        count: number;
        results: Advisor[];
    };


    const [fortunetellers, setFortunetellers] = useState<Advisor[]>([]);
    const [fortunetellersTotal, setFortunetellersTotal] = useState(0);
    const [fortunetellersPage, setFortunetellersPage] = useState(1);
    const [loadingFortunetellers, setLoadingFortunetellers] = useState(false);


    // 検索（ページ内フィルタ）
    const [fortunetellerQuery, setFortunetellerQuery] = useState("");

    // ランク変更モーダル
    const [rankOpen, setRankOpen] = useState(false);
    const [selectedFortuneteller, setSelectedFortuneteller] = useState<Advisor | null>(null);
    const [newRank, setNewRank] = useState<string>("A");
    const [savingRank, setSavingRank] = useState(false);
    const [rankError, setRankError] = useState<string | null>(null);
    const [rankSuccess, setRankSuccess] = useState<string | null>(null);

    const ftPageSize = 20;
    const ftTotalPages = Math.max(1, Math.ceil(fortunetellersTotal / ftPageSize));


    useEffect(() => {
        if (activeTab !== "advisors") return;

        const ctrl = new AbortController();

        (async () => {
            try {
                setLoadingFortunetellers(true);
                const res = await fetch (
                    `${API_BASE}/get_fortunetellers_list/?page=${customersPage}&page_size=20`,
                    { signal: ctrl.signal }
                );
                if (!res.ok) throw new Error (`status${res.status}`);

                const data: AdvisorPageResp = await res.json();
                setFortunetellers(data.results);
                setFortunetellersTotal(data.count);
            } catch (e:any) {
                if (e.name !== "AbortError") {
                    console.error(e)
                }
            } finally {
                setLoadingFortunetellers(false);
            }
        })();
        return () => ctrl.abort();
    }, [activeTab, fortunetellersPage])

    const filteredFortunetellers = (() => {
        const q = fortunetellerQuery.trim().toLowerCase();
        if (!q) return fortunetellers;
        return fortunetellers.filter((f) => {
            return (
                f.id.toLowerCase().includes(q) ||
                f.name.toLowerCase().includes(q) ||
                f.rank.toLowerCase().includes(q) ||
                (f.email?.toLowerCase().includes(q) ?? false)
            );
        });
    })();

    const openRankModal = (f: Advisor) => {
        setSelectedFortuneteller(f);
        setNewRank(f.rank ?? "A");
        setRankError(null);
        setRankSuccess(null);
        setRankOpen(true);
    };

    const closeRankModal = () => {
        if (savingRank) return;
        setRankOpen(false);
        setSelectedFortuneteller(null);
    };

    const submitRankChange = async () => {
        if (!selectedFortuneteller) return;

        setSavingRank(true);
        setRankError(null);
        setRankSuccess(null);

        try {
            // ★あなたの実APIに合わせて変更する箇所
            const res = await fetch(`${API_BASE}/set_fortuneteller_rank/`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    fortuneteller_id: selectedFortuneteller.id,
                    rank: newRank,
                }),
            });

            if (!res.ok) {
                const text = await res.text().catch(() => "");
                throw new Error(`status ${res.status} ${text}`);
            }

            // 画面側も即時反映（再取得しないで更新）
            setFortunetellers((prev) =>
                prev.map((x) => (x.id === selectedFortuneteller.id ? { ...x, rank: newRank } : x))
            );

            setRankSuccess("ランクを更新しました。");
            setTimeout(() => closeRankModal(), 600);
        } catch (e: any) {
            console.error(e);
            setRankError("ランク更新に失敗しました。APIレスポンスを確認してください。");
        } finally {
            setSavingRank(false);
        }
    };


  // -----------------------------
  // 売上申請管理
  // -----------------------------


    type AllSalesObj = {
        id: string;
        name: string;
        amount: number;
        status: string;
    };

    type AllSalesPageResp = {
        count: number;
        results: AllSalesObj[];
    };

    const [allSales, setAllSales] = useState<AllSalesObj[]>([]);
    const [allSalesTotal, setAllSalesTotal] = useState(0);
    const [allSalesPage, setAllSalesPage] = useState(1);
    const [loadingAllSales, setLoadingAllSales] = useState(false);


    const salesPageSize = 20;
    const salesTotalPages = Math.max(1, Math.ceil(allSalesTotal / salesPageSize));

    const fetchSalesList = async (signal?: AbortSignal) => {
        try {
            setLoadingAllSales(true);
            const res = await fetch(
                `${API_BASE}/get_sales_list/?page=${allSalesPage}&page_size=20`,
                {
                    signal,
                    credentials: "include"
                }
            );
            if (!res.ok) throw new Error(`status ${res.status}`);

            const data: AllSalesPageResp = await res.json();
            setAllSales(data.results);
            setAllSalesTotal(data.count);
        } catch (e: any) {
            if (e.name !== "AbortError") {
                console.error("売上リスト取得失敗:", e);
            }
        } finally {
            setLoadingAllSales(false);
        }
    };

    // 2. useEffect は「いつ実行するか」のトリガーだけに絞る
    useEffect(() => {
        if (activeTab !== "sales") return;

        const ctrl = new AbortController();
        fetchSalesList(ctrl.signal);

        return () => ctrl.abort();
    }, [activeTab, allSalesPage]);


    const handleUpdateStatus = async (saleId, newStatus) => {
        let newStatusJp = ""
        switch(newStatus){
            case "APPROVED":
                newStatusJp = "承認済み（支払い未）";
                break;
            case "PAID":
                newStatusJp = "支払い済み";
                break;
        }
        if (!confirm(`ステータスを ${newStatusJp} に変更しますか？`)) return;

        try {
            const res = await fetch(`${API_BASE}/update_payout_status/`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRFToken": csrftoken
                },
                body: JSON.stringify({ sale_id: saleId, new_status: newStatus })
            });

            if (res.ok) {
                fetchSalesList();
            } else {
                alert("更新に失敗しました");
            }
        } catch (e) {
            console.error(e);
            alert("エラーが発生しました");
        }
    };

    const tabs = [
        { id: "dashboard", label: "🏠 ダッシュボード" },
        { id: "customers", label: "👤 顧客管理" },
        { id: "advisors", label: "🧙 占い師管理" },
        { id: "sales", label: "💰 売上・振込" },
        { id: "content", label: "🛠️ 設定" },
    ];

    return (
        <div className="min-h-screen bg-[#0c1a33] text-white">
            {/* Header */}
            <div className="sticky top-0 z-20 p-4 border-b border-white/10 bg-[#0d1a33]">
                <div className="flex items-center justify-between pb-3">
                    <div className="text-xl font-bold text-pink-300">🔮 運営管理者ダッシュボード</div>
                    <button className="text-xs bg-white/10 rounded-full px-3 py-1 border border-white/20">ログアウト</button>
                </div>

                {/* Tabs */}
                <div className="flex flex-wrap gap-2 pt-2">
                    {tabs.map((tab) => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`tab-label rounded-lg px-4 py-2 text-sm border ${activeTab === tab.id
                                    ? "bg-white text-gray-900 font-semibold border-white"
                                    : "bg-white/5 text-white border-white/20"
                                }`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>
            </div>

            {/* Content */}
            <div className="p-4 space-y-6">
                {activeTab === "dashboard" && (
                    <div>
                        <h3 className="text-2xl font-bold text-white/90">🏠 ダッシュボード (KPI)</h3>
                        <div className="grid grid-cols-2 gap-4 mt-4">
                            <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                                <div className="text-sm text-white/70">月間売上（円）</div>
                                <div className="text-2xl font-bold text-yellow-300 mt-1">¥1,250,000</div>
                            </div>
                            <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                                <div className="text-sm text-white/70">未対応振込申請</div>
                                <div className="text-2xl font-bold text-red-400 mt-1">3 件</div>
                            </div>
                        </div>
                    </div>
                )}

                {activeTab === "customers" && (
                    <div className="bg-white/5 p-4 rounded-xl space-y-3">
                        <input
                            type="text"
                            value={customerQuery}
                            onChange={(e) => setCustomerQuery(e.target.value)}
                            placeholder="顧客名、ID、メールで検索..."
                            className="w-full rounded-lg bg-black/30 border border-white/20 px-3 py-2 text-sm placeholder:text-white/50 text-white"
                        />

                        <div className="flex items-center justify-between text-xs text-white/70">
                            <div>{loadingCustomers ? "読み込み中..." : `全 ${customersTotal} 件`}</div>

                            <div className="flex items-center gap-2">
                                <button
                                    className="px-2 py-1 rounded bg-white/10 disabled:opacity-40"
                                    disabled={customersPage <= 1 || loadingCustomers}
                                    onClick={() => setCustomersPage((p) => Math.max(1, p - 1))}
                                >
                                    前へ
                                </button>
                                <span>
                                    {customersPage} / {totalPages}
                                </span>
                                <button
                                    className="px-2 py-1 rounded bg-white/10 disabled:opacity-40"
                                    disabled={customersPage >= totalPages || loadingCustomers}
                                    onClick={() => setCustomersPage((p) => Math.min(totalPages, p + 1))}
                                >
                                    次へ
                                </button>
                            </div>
                        </div>

                        <div className="space-y-2">
                            {loadingCustomers && (
                                <div className="text-sm text-white/70 bg-white/10 p-3 rounded">
                                    顧客一覧を読み込み中...
                                </div>
                            )}

                            {!loadingCustomers && filteredCustomers.length === 0 && (
                                <div className="text-sm text-white/70 bg-white/10 p-3 rounded">
                                    表示できる顧客がありません。
                                </div>
                            )}

                            {!loadingCustomers &&
                                filteredCustomers.map((c) => (
                                    <div
                                        key={c.id}
                                        className="flex justify-between items-center bg-white/10 p-3 rounded-lg"
                                    >
                                        <div className="space-y-0.5">
                                            <div className="font-semibold">#{c.id}{c.name}</div>
                                            {c.email && <div className="text-xs text-white/70">{c.email}</div>}
                                        </div>

                                        <button
                                            className="text-xs bg-pink-500 hover:bg-pink-400 rounded px-3 py-2 disabled:opacity-60"
                                            onClick={() => openGrantModal(c)}
                                            disabled={loadingCustomers}
                                        >
                                            ポイント付与
                                        </button>
                                    </div>
                                ))}
                        </div>

                        {/* ✅ ポイント付与モーダル */}
                        <Modal
                            open={grantOpen}
                            title={
                                selectedCustomer
                                    ? `ポイント付与：#${selectedCustomer.id}（${selectedCustomer.name}）`
                                    : "ポイント付与"
                            }
                            onClose={closeGrantModal}
                        >
                            <div className="space-y-3">
                                <div className="text-xs text-white/70">
                                    付与するポイント数を入力して「付与する」を押してください。
                                </div>

                                <div className="space-y-1">
                                    <label className="text-xs text-white/70">ポイント</label>
                                    <input
                                        type="number"
                                        min={1}
                                        step={1}
                                        value={grantPoints}
                                        onChange={(e) => setGrantPoints(Number(e.target.value))}
                                        className="w-full rounded-lg bg-black/30 border border-white/20 px-3 py-2 text-sm text-white"
                                    />
                                </div>

                                <div className="space-y-1">
                                    <label className="text-xs text-white/70">メモ（任意）</label>
                                    <textarea
                                        value={grantNote}
                                        onChange={(e) => setGrantNote(e.target.value)}
                                        rows={3}
                                        className="w-full rounded-lg bg-black/30 border border-white/20 px-3 py-2 text-sm text-white"
                                        placeholder="例：キャンペーン対応"
                                    />
                                </div>

                                {grantError && (
                                    <div className="text-sm text-red-300 bg-red-500/10 border border-red-500/20 p-2 rounded">
                                        {grantError}
                                    </div>
                                )}

                                {grantSuccess && (
                                    <div className="text-sm text-green-300 bg-green-500/10 border border-green-500/20 p-2 rounded">
                                        {grantSuccess}
                                    </div>
                                )}

                                <div className="flex items-center justify-end gap-2 pt-2">
                                    <button
                                        className="px-3 py-2 rounded bg-white/10 hover:bg-white/20 text-sm disabled:opacity-60"
                                        onClick={closeGrantModal}
                                        disabled={granting}
                                    >
                                        キャンセル
                                    </button>
                                    <button
                                        className="px-3 py-2 rounded bg-pink-500 hover:bg-pink-400 text-sm disabled:opacity-60"
                                        onClick={submitGrantPoints}
                                        disabled={granting || !selectedCustomer}
                                    >
                                        {granting ? "付与中..." : "付与する"}
                                    </button>
                                </div>
                            </div>
                        </Modal>
                    </div>
                )}
                {activeTab === "advisors" && (
                    <div className="bg-white/5 p-4 rounded-xl space-y-3">
                        <input
                            type="text"
                            value={fortunetellerQuery}
                            onChange={(e) => setFortunetellerQuery(e.target.value)}
                            placeholder="占い師名、ID、ランクで検索..."
                            className="w-full rounded-lg bg-black/30 border border-white/20 px-3 py-2 text-sm placeholder:text-white/50 text-white"
                        />

                        <div className="flex items-center justify-between text-xs text-white/70">
                            <div>{loadingFortunetellers ? "読み込み中..." : `全 ${fortunetellersTotal} 件`}</div>

                            <div className="flex items-center gap-2">
                                <button
                                    className="px-2 py-1 rounded bg-white/10 disabled:opacity-40"
                                    disabled={fortunetellersPage <= 1 || loadingFortunetellers}
                                    onClick={() => setFortunetellersPage((p) => Math.max(1, p - 1))}
                                >
                                    前へ
                                </button>
                                <span>
                                    {fortunetellersPage} / {ftTotalPages}
                                </span>
                                <button
                                    className="px-2 py-1 rounded bg-white/10 disabled:opacity-40"
                                    disabled={fortunetellersPage >= ftTotalPages || loadingFortunetellers}
                                    onClick={() => setFortunetellersPage((p) => Math.min(ftTotalPages, p + 1))}
                                >
                                    次へ
                                </button>
                            </div>
                        </div>

                        <div className="text-xs text-white/70">
                            （APIで取得した占い師一覧を表示。ランク変更ボタンでモーダルを開いて更新します。）
                        </div>

                        <div className="space-y-2">
                            {loadingFortunetellers && (
                                <div className="text-sm text-white/70 bg-white/10 p-3 rounded">
                                    占い師一覧を読み込み中...
                                </div>
                            )}

                            {!loadingFortunetellers && filteredFortunetellers.length === 0 && (
                                <div className="text-sm text-white/70 bg-white/10 p-3 rounded">
                                    表示できる占い師がいません。
                                </div>
                            )}

                            {!loadingFortunetellers &&
                                filteredFortunetellers.map((f) => (
                                    <div
                                        key={f.id}
                                        className="flex justify-between items-center bg-white/10 p-3 rounded-lg"
                                    >
                                        <div className="space-y-0.5">
                                            <div className="font-semibold text-white">
                                                #{f.id}（{f.name}） <span className="text-white/70">({f.rank}ランク)</span>
                                            </div>
                                            {f.email && <div className="text-xs text-white/70">{f.email}</div>}
                                        </div>

                                        <button
                                            className="text-xs bg-amber-500 hover:bg-amber-400 text-gray-900 rounded px-3 py-2 disabled:opacity-60"
                                            onClick={() => openRankModal(f)}
                                            disabled={loadingFortunetellers}
                                        >
                                            ランク変更
                                        </button>
                                    </div>
                                ))}
                        </div>

                        {/* ランク変更モーダル（Modalは使い回し） */}
                        <Modal
                            open={rankOpen}
                            title={
                                selectedFortuneteller
                                    ? `ランク変更：#${selectedFortuneteller.id}（${selectedFortuneteller.name}）`
                                    : "ランク変更"
                            }
                            onClose={closeRankModal}
                        >
                            <div className="space-y-3">
                                <div className="text-xs text-white/70">
                                    新しいランクを選択して「更新」を押してください。
                                </div>

                                <div className="space-y-1">
                                    <label className="text-xs text-white/70">ランク</label>
                                    <select
                                        value={newRank}
                                        onChange={(e) => setNewRank(e.target.value)}
                                        className="w-full rounded-lg bg-black/30 border border-white/20 px-3 py-2 text-sm text-white"
                                        disabled={savingRank}
                                    >
                                        {/* あなたのランク体系に合わせて増減OK */}
                                        <option value="S">S</option>
                                        <option value="A">A</option>
                                        <option value="B">B</option>
                                        <option value="C">C</option>
                                    </select>
                                </div>

                                {rankError && (
                                    <div className="text-sm text-red-300 bg-red-500/10 border border-red-500/20 p-2 rounded">
                                        {rankError}
                                    </div>
                                )}

                                {rankSuccess && (
                                    <div className="text-sm text-green-300 bg-green-500/10 border border-green-500/20 p-2 rounded">
                                        {rankSuccess}
                                    </div>
                                )}

                                <div className="flex items-center justify-end gap-2 pt-2">
                                    <button
                                        className="px-3 py-2 rounded bg-white/10 hover:bg-white/20 text-sm disabled:opacity-60"
                                        onClick={closeRankModal}
                                        disabled={savingRank}
                                    >
                                        キャンセル
                                    </button>
                                    <button
                                        className="px-3 py-2 rounded bg-amber-500 hover:bg-amber-400 text-gray-900 text-sm disabled:opacity-60"
                                        onClick={submitRankChange}
                                        disabled={savingRank || !selectedFortuneteller}
                                    >
                                        {savingRank ? "更新中..." : "更新"}
                                    </button>
                                </div>
                            </div>
                        </Modal>
                    </div>
                )}
                {activeTab === "sales" && (
                    <div className="bg-white/5 p-4 rounded-xl space-y-4">
                        <div className="flex justify-between items-center">
                            <h4 className="text-lg font-semibold text-pink-300">
                                振込申請管理 ({allSalesTotal}件)
                            </h4>
                        </div>

                        {loadingAllSales ? (
                            <div className="text-center py-4 text-white/50">読み込み中...</div>
                        ) : allSales.length === 0 ? (
                            <div className="text-center py-4 text-white/50">申請はありません</div>
                        ) : (
                            <div className="space-y-2">
                                {allSales.map((sale) => (
                                    <div key={sale.id} className="flex justify-between items-center bg-white/10 p-3 rounded-lg border border-white/5">
                                        <div className="flex flex-col">
                                            <span className="font-semibold text-white">{sale.name}</span>
                                            <span className="text-sm text-pink-200">¥{sale.amount.toLocaleString()}</span>
                                        </div>

                                        <div>
                                            {/* --- ステータスによる分岐 --- */}
                                            {sale.status === "UNAPPROVED" && (
                                                <button
                                                    onClick={() => handleUpdateStatus(sale.id, "APPROVED")}
                                                    className="text-xs bg-green-600 hover:bg-green-500 text-white rounded px-3 py-1.5 transition-colors"
                                                >
                                                    承認する
                                                </button>
                                            )}

                                            {sale.status === "APPROVED" && (
                                                <button
                                                    onClick={() => handleUpdateStatus(sale.id, "PAID")}
                                                    className="text-xs bg-blue-600 hover:bg-blue-500 text-white rounded px-3 py-1.5 transition-colors"
                                                >
                                                    支払い済みに変更
                                                </button>
                                            )}

                                            {sale.status === "PAID" && (
                                                <span className="text-xs bg-white/20 text-white/60 rounded px-3 py-1.5 border border-white/10">
                                                    支払い済み
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}

                        {/* 必要に応じてここにページネーションを追加 */}
                    </div>
                )}
                {activeTab === "content" && (
                <div>
                    <h3 className="text-2xl font-bold text-white/90 mb-3">
                    🛠️ 設定セクション（テストAPI）
                    </h3>

                    {loadingUsers && <p>読み込み中...</p>}
                    {usersError && <p className="text-red-400">{usersError}</p>}

                    {!loadingUsers && !usersError && (
                    <div className="bg-white/5 border border-white/10 rounded-lg px-3 py-2">
                        {/* Djangoからのレスポンスメッセージを表示 */}
                        <p className="text-white/80">
                        {users.length > 0
                            ? JSON.stringify(users) // usersが配列じゃなくオブジェクトでも表示できる
                            : message
                            ? message
                            : "データがありません"}
                        </p>
                    </div>
                    )}
                </div>
                )}
            </div>
        </div>
    );
}

// ReactDOM.createRoot(document.getElementById("root")!).render(
//     <React.StrictMode>
//         <AdminApp />
//     </React.StrictMode>
// );
