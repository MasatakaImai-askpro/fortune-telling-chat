from django.urls import path
from .views import (
    HelloView,
    QuerentKarteView,
    QuerentRegistrationView,
    FortunetellerRegistrationView,
    UserLogin,
    UserLogout,
    UserLoginInfo,
    GETFortuneTeller,
    FortunetellerInfo,
    FortunetellerBankInfo,
    FortunetellerSalesInfo,
    chatRoomInfo,
    FortunetellerChatInfo,
    FortunetellerChatMessage,
    sendDM,
    QuerentInfo,
    QuerentChatMessage,
    sendUserMessage,
    UnlockMessage,
    UserFavorite,
    AdminQuerentListView,
    AdminFortunetellerListView,
    AdminSalesListView,
    stripe_webhook,
    create_portal_session
)

print("LOADED api.urls:", __file__)

urlpatterns = [
    path("users/", HelloView.as_view()),
    path("user_login/", UserLogin.as_view()),
    path("user_logout/", UserLogout.as_view()),
    path("post_user_fav",UserFavorite.as_view()),
    path("get_user_fav/", UserFavorite.as_view()),
    path("get_login_info/", UserLoginInfo.as_view()),
    path("get_querent_info/", QuerentInfo.as_view()),
    path("get_chat_message/", QuerentChatMessage.as_view()),
    path("create_querent_user/", QuerentRegistrationView.as_view()),
    path("create_fortune_user/", FortunetellerRegistrationView.as_view()),
    path("get_fortuneteller_all/", GETFortuneTeller.as_view()),
    path("get_fortuneteller_info/", FortunetellerInfo.as_view()),
    path("get_fortuneteller_bank_info/", FortunetellerBankInfo.as_view()),
    path("get_sales_info/", FortunetellerSalesInfo.as_view()),
    path("create_payout_request/", FortunetellerSalesInfo.as_view()),
    path("get_room/",chatRoomInfo.as_view()),
    path("edit_querent_karte/", QuerentKarteView.as_view()),
    path("edit_fortuneteller_pro/", FortunetellerInfo.as_view()),
    path("edit_fortuneteller_bank_info/",FortunetellerBankInfo.as_view()),
    path("get_fortuneteller_room_info/",FortunetellerChatInfo.as_view()),
    path("get_fortuneteller_room_messages/", FortunetellerChatMessage.as_view()),
    path("dm_simultaneous_transmission/", sendDM.as_view()),
    path("send_messages/",sendUserMessage.as_view()),
    path("unlock_message/",UnlockMessage.as_view()),
    # 決済url
    path('stripe/webhook/', stripe_webhook, name='stripe_webhook'),
    # 解約url
    path('stripe/create_portal_session/', create_portal_session, name='create-portal-session'),
    # 管理者ページ内、相談者取得
    path('get_querents_list/', AdminQuerentListView.as_view(), name='get_querent_list'),
    # 管理者ページ内、占い師取得
    path('get_fortunetellers_list/', AdminFortunetellerListView.as_view(), name="get_fortuneteller_list"),
    path('get_sales_list/', AdminSalesListView.as_view(), name="get_sales_list"),
    path("update_payout_status/",AdminSalesListView.as_view(), name="update_payout_status")
]
