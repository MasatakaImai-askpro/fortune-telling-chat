from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout
from django.db import transaction
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework import status
from .models import (
    User,
    FortunetellerProfile,
    QuerentProfile,
    BankInfo,
    Room,
    Message,
    Favorite,
    PayoutRequest,
)
from .serializers import (
    FortunetellerRegistrationSerializer,
    BankInfoSerializer,
    RoomSerializer,
    QuerentRegistrationSerializer,
    MessageSerializer,
    AdminQuerentListSerializer,
    AdminFortunetellerListSerializer,
    AdminSalesListSerializer,
)
from rest_framework.permissions import IsAuthenticated, AllowAny
from django.db import transaction
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from .utils import message_to_payload
from django.conf import settings
import stripe
from django.views.decorators.csrf import csrf_exempt
from django.db.models import F
from rest_framework.generics import ListAPIView
from django.db.models import Sum
from rest_framework.pagination import PageNumberPagination
from django.utils import timezone


class HelloView(APIView):
    def get(self, request):
        return Response({"message": "Hello from Django!"})


# 相談者登録ビュー
class QuerentRegistrationView(APIView):
    renderer_classes = [JSONRenderer]

    def post(self, request):
        data = request.data
        if data:
            serializer = QuerentRegistrationSerializer(data=data)
            try:
                if serializer.is_valid(raise_exception=True):
                    assert not hasattr(serializer, "_data")
                    user = serializer.save()
                    login(request, user)
                    return Response(status=status.HTTP_201_CREATED)
            except Exception as e:
                return Response(
                    f"エラーが発生しました: {e}", status=status.HTTP_400_BAD_REQUEST
                )
            return Response(status=status.HTTP_400_BAD_REQUEST)


# カルテ編集
class QuerentKarteView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        data = request.data.copy
        birthday = data.get("birthday")
        zodiac = data.get("zodiac")
        birthplace = data.get("birthplace")
        birthtime = data.get("birthtime")
        genre = data.get("genre")
        body = data.get("body")
        return Response(status=status.HTTP_201_CREATED)


# 相談者の会員情報,カルテ情報取得
class QuerentInfo(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if not request.user.is_authenticated:
            return Response({}, status=400)
        user_obj = QuerentProfile.objects.get(user=user)
        return Response(
            {
                "id": user_obj.user_id,
                "name": user_obj.name,
                "email": user.email,
                "tel_number": user_obj.tel_number,
                "postal_code": user_obj.postal_code,
                "address": user_obj.address,
                "birthdate": user_obj.birthdate,
                "zodiac_sign": user_obj.zodiac_sign,
                "birthplace": user_obj.birthplace,
                "birthtime": user_obj.birthtime,
                "worry_category": user_obj.worry_category,
                "worry_message": user_obj.worry_message,
                "subscription": user_obj.is_subscription,
                "point": user_obj.points,
            },
            status=status.HTTP_200_OK,
        )


class QuerentChatMessage(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        fortuneteller_id = request.query_params.get("advisor_id")
        querent_id = request.user.id
        room = Room.objects.filter(
            fortuneteller_id=fortuneteller_id, querent_id=querent_id
        ).first()
        if not room:
            return Response({"messages": [], "room_id": None}, status=200)

        messages = Message.objects.filter(room=room).order_by("created_at")

        return Response(
            {
                "room_id": room.id,
                "advisor_id": fortuneteller_id,
                "messages": [
                    {
                        "id": message.id,
                        "sender": message.sender,
                        "text": message.text,
                        "created_at": message.created_at.isoformat(),
                    }
                    for message in messages
                ],
            }
        )


# お気に入りPOST、GET
class UserFavorite(APIView):
    def post(self, request):
        user = request.user
        fortuneteller_id = request.data.get("adviser_id")

        if not fortuneteller_id:
            return Response(
                {"error": "adviser_idが必要です"}, status=status.HTTP_400_BAD_REQUEST
            )

        try:
            # 1. お気に入りのトグル処理
            favorite, created = Favorite.objects.get_or_create(
                fortuneteller_id=fortuneteller_id, querent_id=user.id
            )

            if not created:
                favorite.delete()
                is_favorite = False
            else:
                is_favorite = True

            updated_favorites = Favorite.objects.filter(querent_id=user.id).values_list(
                "fortuneteller_id", flat=True
            )

            return Response(
                {"is_favorite": is_favorite, "favorites": list(updated_favorites)},
                status=status.HTTP_200_OK,
            )

        except Exception as e:
            return Response(
                {"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def get(request):
        favorite_ids = Favorite.objects.filter(querent_id=request.user.id).values_list(
            "fortuneteller_id", flat=True
        )
        return Response(list(favorite_ids))


# 占い師登録ビュー
class FortunetellerRegistrationView(APIView):
    def post(self, request):
        data = request.data
        if data:
            serializer = FortunetellerRegistrationSerializer(data=data)
            try:
                if serializer.is_valid(raise_exception=True):
                    serializer.save()
                    return Response(status=status.HTTP_201_CREATED)
            except Exception as e:
                return Response(
                    f"エラーが発生しました: {e}", status=status.HTTP_400_BAD_REQUEST
                )
            return Response(status=status.HTTP_400_BAD_REQUEST)


class UserLogin(APIView):
    def post(self, request):
        data = request.data
        if data:
            email = data.get("email")
            pw = data.get("password")
            login_role = data.get("role")

            user = authenticate(request, email=email, password=pw)
            if user is not None:
                if user.role != login_role:
                    return Response(
                        {"error": "ログイン画面が異なります。"},
                        status=status.HTTP_401_UNAUTHORIZED,
                    )
                login(request, user)
                return Response(
                    {"message": "ログイン成功", "user_role": user.role},
                    status.HTTP_200_OK,
                )
            else:
                return Response(
                    {"error": "認証に失敗しました"}, status=status.HTTP_401_UNAUTHORIZED
                )


class UserLogout(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        logout(request)

        return Response(
            {"detail": "Successfully logged out."}, status=status.HTTP_200_OK
        )


class UserLoginInfo(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        if not request.user.is_authenticated:
            return Response(None, status=200)
        user = request.user
        return Response(
            {
                "id": user.id,
                "email": user.email,
                "role": user.role,
            }
        )


class GETFortuneTeller(APIView):
    def get(self, request):
        fortunetellers = FortunetellerProfile.objects.all()
        fortuneteller_list = []
        for fortuneteller in fortunetellers:
            fortuneteller_list.append(
                {
                    "id": fortuneteller.user.id,
                    "name": fortuneteller.name,
                    "rank": fortuneteller.rank,
                    # ここは後ほど書き換え
                    "tags": ["霊視", "スピリチュアル", "恋愛"],
                    "profile_image": request.build_absolute_uri(
                        fortuneteller.profile_image.url
                    ),
                    "icon_image": request.build_absolute_uri(
                        fortuneteller.icon_image.url
                    ),
                    "headline": fortuneteller.headline,
                    "intro": fortuneteller.intro,
                    "is_recommended": fortuneteller.is_recommended,
                }
            )
        return Response(fortuneteller_list, status=status.HTTP_200_OK)


# 占い師のプロフィール
class FortunetellerInfo(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if user.role != "2":
            return Response(status=status.HTTP_400_BAD_REQUEST)
        return Response(
            {
                "id": user.id,
                "name": user.fortune_pro.name,
                "rank": user.fortune_pro.rank,
                "headline": user.fortune_pro.headline,
                "intro": user.fortune_pro.intro,
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request):
        data = request.data
        name = data.get("name")
        headline = data.get("headline")
        intro = data.get("intro")
        user = request.user
        if user:
            try:
                pro_obj = FortunetellerProfile.objects.get(user=user)
                pro_obj.name = (name,)
                pro_obj.headline = (headline,)
                pro_obj.intro = intro
                pro_obj.save()
                return Response(status=status.HTTP_200_OK)
            except Exception as e:
                print(e)
                return Response(status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)


# 占い師の口座情報
class FortunetellerBankInfo(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        fortune_pro = FortunetellerProfile.objects.get(user=user)
        bank_infos = BankInfo.objects.filter(user=fortune_pro).first()
        if bank_infos is None:
            return Response(
                {
                    "name": "",
                    "branch_name": "",
                    "account_type": "",
                    "account_number": "",
                    "acount_holder_name": "",
                },
                status=status.HTTP_200_OK,
            )
        else:
            serializer = BankInfoSerializer(bank_infos)
            # print(serializer.data)
            return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request):
        data = request.data.copy()
        fortune_pro = FortunetellerProfile.objects.get(user=request.user)
        bank_info = BankInfo.objects.filter(user=fortune_pro).first()
        if bank_info:
            serializer = BankInfoSerializer(instance=bank_info, data=data)
        else:
            serializer = BankInfoSerializer(data=data)

        if serializer.is_valid(raise_exception=True):
            if bank_info:
                serializer.save(user=fortune_pro)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                serializer.save(user=fortune_pro)
                return Response(serializer.data, status=status.HTTP_201_CREATED)


# 占い師の売り上げ情報
class FortunetellerSalesInfo(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        exchange_rate = 1
        total_sales_point = (
            Message.objects.filter(
                room__fortuneteller__user_id=user.id,
                cost_pt__isnull=False,
                is_locked=False,
            ).aggregate(total=Sum("cost_pt"))["total"]
            or 0
        )

        # 売上総額
        total_sales = total_sales_point * exchange_rate

        # 過去の申請履歴を抽出（未承認と承認済みのみ）
        target_status = ["APPROVED", "PAID", "UNAPPROVED"]
        amount_to_subtract = (
            PayoutRequest.objects.filter(
                user=user.id, status__in=target_status
            ).aggregate(total=Sum("amount"))["total"]
            or 0
        )

        # 振込可能金額
        transferable_balance = total_sales - amount_to_subtract

        return Response(
            {"total_sales": total_sales, "transferable_balance": transferable_balance},
            status=200,
        )

    def post(self, request):
        data = request.data
        user_id = data.get("user_id")
        amount = data.get("amount")

        try:
            # 申請を作成
            PayoutRequest.objects.create(
                user_id=user_id, amount=amount, status="UNAPPROVED"
            )
            return Response(
                {"message": "申請が完了しました"}, status=status.HTTP_201_CREATED
            )

        except Exception as e:
            print(e)
            return Response(
                {"error": "申請の保存中にエラーが発生しました。"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class chatRoomInfo(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        fortuneteller_id = request.query_params.get("fortuneteller")

        if not fortuneteller_id:
            return Response({"error": "advisor required"}, status=400)

        fortuneteller_user = User.objects.get(id=fortuneteller_id)
        fortuneteller_pro_obj = FortunetellerProfile.objects.get(
            user=fortuneteller_user
        )
        querent_user = User.objects.get(id=request.user.id)
        querent_pro_obj = QuerentProfile.objects.get(user=querent_user)

        room = Room.objects.filter(
            fortuneteller_id=fortuneteller_pro_obj, querent_id=querent_pro_obj
        ).first()
        if room is None:
            return Response({"id": None}, status=200)
        return Response({"id": room.id}, status=200)


class FortunetellerChatInfo(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        room_infos = Room.objects.filter(fortuneteller_id=user.id)
        room_list = []

        for room_info in room_infos:
            room_id = room_info.id
            try:
                last_msg = (
                    Message.objects.filter(room=room_id, sender="querent")
                    .order_by("-created_at")
                    .first()
                )
            except Exception as e:
                print(e)
                return Response({f"error:{e}"})

            room_list.append(
                {
                    "id": room_id,
                    "last_msg": last_msg.text,
                    "msg_created_at": last_msg.created_at,
                    "que_name": room_info.querent.name,
                    "birthdate": room_info.querent.birthdate,
                    "zodiac": room_info.querent.zodiac_sign,
                    "birthplace": room_info.querent.birthplace,
                    "birthtime": room_info.querent.birthtime,
                    "worry_category": room_info.querent.worry_category,
                    "worry_message": room_info.querent.worry_message,
                }
            )
        return Response(room_list, status=status.HTTP_200_OK)


class FortunetellerChatMessage(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        room_id = request.query_params.get("room_id")

        if not room_id:
            return Response({"error": "room_id is required"}, status=400)

        try:
            room = Room.objects.get(id=room_id, fortuneteller_id=user.id)
        except Room.DoesNotExist:
            return Response({"error": "Room not found"}, status=404)

        messages = Message.objects.filter(room=room_id).order_by("created_at")
        message_arr = []
        for message in messages:
            iso_created_at = message.created_at.isoformat()
            data = {
                "id": message.id,
                "sender": message.sender,
                "text": message.text,
                "created_at": iso_created_at,
            }
            message_arr.append(data)
        return Response(message_arr, status=status.HTTP_200_OK)


class sendDM(APIView):
    def post(self, request):
        user = request.user
        data = request.data
        room_ids = data.get("ids")
        text = data.get("dm_text")

        if not room_ids:
            return Response({"error": "no targets"}, status=400)

        messages = [
            Message(
                room_id=room,
                sender="fortuneteller",
                text=text,
            )
            for room in room_ids
        ]
        Message.objects.bulk_create(messages)

        return Response({"success": len(messages)}, status=201)


class sendUserMessage(APIView):
    def post(self, request):
        user = request.user
        data = request.data

        room_id = data.get("room_id")
        fortuneteller_id = data.get("advisor_id")
        sender = data.get("sender")
        text = data.get("text", "")
        category = data.get("category", "normal")
        point = data.get("point")
        file = request.FILES.get("file")

        if room_id:
            try:
                room = Room.objects.get(id=room_id)
            except Room.DoesNotExist:
                return Response({"detail": "room not found"}, status=404)
        else:
            if not fortuneteller_id:
                return Response({"detail": "advisor_id required"}, status=400)

            try:
                room, _created = Room.objects.get_or_create(
                    fortuneteller_id=fortuneteller_id, querent_id=user.id
                )
            except Exception as e:
                print(e)
                return Response({"detail": "failed"}, status=400)

        cost_pt = 0
        is_locked = False

        if sender == "fortuneteller":
            if category == "length_paying":
                cost_pt = len(text) * 2
                is_locked = True
            elif category == "healing":
                cost_pt = int(point or 0)
                is_locked = True if cost_pt > 0 else False
            else:
                cost_pt = 0
                is_locked = False
        else:
            cost_pt = int(data.get("cost_pt") or 0)
            is_locked = False

        try:
            with transaction.atomic():
                message = Message.objects.create(
                    room=room,
                    sender=sender,
                    text=text,
                    file=file,
                    cost_pt=cost_pt,
                    is_locked=is_locked,
                )

                payload = message_to_payload(message, request=request)  # 絶対URL化
                group_name = f"room_{room.id}"
                channel_layer = get_channel_layer()

                if sender == "querent":
                    querent_pro = QuerentProfile.objects.get(user_id=user.id)
                    remaining_point = int(querent_pro.points) - int(cost_pt)
                    querent_pro.points = remaining_point
                    querent_pro.save(update_fields=["points"])

                def notify():
                    async_to_sync(channel_layer.group_send)(
                        group_name, {"type": "broadcast_message", "payload": payload}
                    )

                transaction.on_commit(notify)

        except Exception as e:
            print(e)
            return Response({"detail": "failed"}, status=400)

        serializer = MessageSerializer(message, context={"request": request})
        response_data = serializer.data
        response_data["room_id"] = room.id

        if sender == "querent":
            response_data["current_point"] = querent_pro.points

        return Response(response_data, status=status.HTTP_201_CREATED)


class UnlockMessage(APIView):
    def post(self, request):
        user = request.user
        message_id = request.data.get("message_id")

        if not message_id:
            return Response({"detail": "message_id required"}, status=400)

        with transaction.atomic():
            msg = (
                Message.objects.select_for_update()
                .select_related("room")
                .filter(id=message_id)
                .first()
            )

            if not msg:
                return Response({"detail": "message not found"}, status=404)

            if msg.sender != "fortuneteller":
                return Response({"detail": "not chargeable"}, status=400)

            if not msg.is_locked:
                serializer = MessageSerializer(msg, context={"request": request})
                data = serializer.data
                data["current_point"] = QuerentProfile.objects.get(
                    user_id=user.id
                ).points
                return Response(data, status=200)

            cost = int(msg.cost_pt or 0)
            qp = QuerentProfile.objects.select_for_update().get(user_id=user.id)

            if int(qp.points) < cost:
                return Response(
                    {
                        "detail": "insufficient_points",
                        "need": cost,
                        "current": int(qp.points),
                    },
                    status=402,
                )

            qp.points = F("points") - cost
            qp.save(update_fields=["points"])
            qp.refresh_from_db(fields=["points"])

            # unlock
            msg.is_locked = False
            msg.save(update_fields=["is_locked"])

            serializer = MessageSerializer(msg, context={"request": request})
            data = serializer.data
            data["current_point"] = int(qp.points)

            return Response(data, status=200)


# 管理画面・顧客一覧取得クラス
class AdminQuerentListView(ListAPIView):
    queryset = User.objects.all().filter(role=1).order_by("-id")
    serializer_class = AdminQuerentListSerializer


# 管理画面・占い師一覧取得クラス
class AdminFortunetellerListView(ListAPIView):
    queryset = User.objects.all().filter(role=2).order_by("-id")
    serializer_class = AdminFortunetellerListSerializer


# 管理画面・売上申請取得クラス
class AdminSalesListView(ListAPIView):
    def get(self, request):
        queryset = PayoutRequest.objects.all().order_by("-id")

        paginator = PageNumberPagination()
        paginator.page_size = request.query_params.get("page_size", 20)
        result_page = paginator.paginate_queryset(queryset, request)

        serializer = AdminSalesListSerializer(result_page, many=True)
        return paginator.get_paginated_response(serializer.data)

    def post(self, request):
        data = request.data
        sales_id = data.get("sale_id")
        new_status = data.get("new_status")

        if not sales_id or not new_status:
            return Response(
                {"error": "IDとステータスが必要です"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            payout_req_obj = PayoutRequest.objects.get(id=sales_id)
            payout_req_obj.status = new_status
            payout_req_obj.updated_at = timezone.now()
            payout_req_obj.save(update_fields=["status"])
            return Response({"message": "更新しました"}, status=status.HTTP_200_OK)
        except PayoutRequest.DoesNotExist:
            return Response(
                {"error": "該当の申請が見つかりません"},
                status=status.HTTP_404_NOT_FOUND,
            )


@csrf_exempt
def stripe_webhook(request):
    payload = request.body
    sig_header = request.META.get("HTTP_STRIPE_SIGNATURE")
    endpoint_secret = settings.STRIPE_WEBHOOK_SECRET

    try:
        event = stripe.Webhook.construct_event(payload, sig_header, endpoint_secret)
    except Exception as e:
        return HttpResponse(status=400)

    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        user_id = session.get("client_reference_id")
        amount = session.get("amount_total")
        customer_id = session.get("customer")

        if not user_id:
            return HttpResponse(status=400)

        try:
            querent_pro = QuerentProfile.objects.get(user_id=user_id)

            mode = session.get("mode")
            if mode == "subscription":
                querent_pro.is_subscription = True
                querent_pro.stripe_customer_id = customer_id
                querent_pro.save(
                    update_fields=["is_subscription", "stripe_customer_id"]
                )
            else:
                set_point = 1000 if amount == 1000 else 3000
                querent_pro.points += set_point
                querent_pro.save(update_fields=["points"])

        except QuerentProfile.DoesNotExist:
            return HttpResponse(status=404)
        except Exception as e:
            return HttpResponse(status=500)

        return HttpResponse(status=200)

    elif event["type"] == "customer.subscription.deleted":
        session = event["data"]["object"]
        customer_id = session.get("customer")

        if not customer_id:
            return HttpResponse(status=400)

        try:
            app_pro = QuerentProfile.objects.get(stripe_customer_id=customer_id)
            app_pro.is_subscription = False
            app_pro.stripe_customer_id = None
            app_pro.save(update_fields=["is_subscription", "stripe_customer_id"])

        except QuerentProfile.DoesNotExist:
            return HttpResponse(status=404)
        except Exception as e:
            return HttpResponse(status=500)

    return HttpResponse(status=200)


stripe.api_key = settings.STRIPE_SECRET_KEY


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def create_portal_session(request):
    user = request.user

    try:
        customer_id = user.querent_pro.stripe_customer_id

        if not customer_id:
            return Response({"error": "決済情報が見つかりません。"}, status=400)

        portal_session = stripe.billing_portal.Session.create(
            customer=customer_id, return_url="http://localhost:5173/"
        )
        return Response({"url": portal_session.url})
    except Exception as e:
        return Response({"error": str(e)}, status=500)
