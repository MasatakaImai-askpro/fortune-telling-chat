from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout
from django.db import transaction
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from .models import User, FortunetellerProfile, QuerentProfile, BankInfo, Room, Message
from .serializers import (
    FortunetellerRegistrationSerializer,
    BankInfoSerializer,
    RoomSerializer,
    QuerentRegistrationSerializer,
    MessageSerializer 
)
from rest_framework.permissions import IsAuthenticated, AllowAny
from django.db import transaction


def _get_file_type(filename: str) -> str:
    ext = (filename.split(".")[-1] if filename and "." in filename else "").lower()
    if ext in ["jpg", "jpeg", "png", "gif", "webp"]:
        return "image"
    if ext in ["mp4", "mov", "webm"]:
        return "video"
    return "file"


def message_to_payload(message, request=None, base_url: str | None = None):
    attachments = []

    f = getattr(message, "file", None)
    if f:
        filename = getattr(f, "name", "file")
        url = f.url
        if request is not None:
            url = request.build_absolute_uri(url)
        elif base_url:
            url = base_url.rstrip("/") + url

        attachments = [{
            "type": _get_file_type(filename),
            "url": url,
            "name": filename.split("/")[-1],
        }]

    is_locked = bool(getattr(message, "is_locked", False))
    cost_pt = int(getattr(message, "cost_pt", 0) or 0)
    
    text = message.text or ""
    if message.sender == "fortuneteller" and is_locked:
        text = ""

    return {
        "id": str(message.id),
        "sender": message.sender,
        "text": message.text or "",
        "created_at": message.created_at.isoformat(),
        "attachments": attachments,
        "free": False,
        "point": cost_pt,
        "is_locked": is_locked,
        "masked": (message.sender == "fortuneteller" and is_locked),
    }