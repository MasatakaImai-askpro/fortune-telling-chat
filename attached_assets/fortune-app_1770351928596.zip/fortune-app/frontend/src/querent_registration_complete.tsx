// import React from "react";
// import { CheckCircle2 } from "lucide-react";
// import { useNavigate } from "react-router-dom";
// import ReactDOM from "react-dom/client";
import { useNavigate } from "react-router-dom";
import "./index.css";
import { CheckCircle2 } from "lucide-react";

export default function QuerentRegistrationComplete() {
    const navigate = useNavigate();

    return (
        <div className="min-h-screen bg-[#0c1a33] text-white flex items-start justify-center p-6 pt-16">
            <div className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 shadow-xl space-y-6">
                {/* ヘッダー */}
                <div className="text-center space-y-2">
                    <div className="flex items-center justify-center gap-2">
                        <CheckCircle2 className="w-6 h-6 text-emerald-300" />
                        <div className="text-xl font-bold">会員登録が完了しました</div>
                    </div>
                    <div className="text-[12px] text-white/70 leading-relaxed">
                        ご登録ありがとうございます。
                        <br />
                        続けてログインしてご利用を開始できます。<br />
                        ※占い師への相談にはポイントの購入、もしくはサブスクリプションへの登録が必要となります。
                    </div>
                </div>

                {/* 案内カード */}
                {/* <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3">
                    <div className="text-sm font-semibold text-white/90">
                        次のステップ
                    </div>
                    <div className="text-[12px] text-white/70 leading-relaxed">
                        「ログインはこちら」からログイン画面へ進み、メールアドレスとパスワードを入力してください。
                    </div>
                    <div className="text-[11px] text-white/50 leading-relaxed">
                        ※ もし自動ログインが有効な場合は、このままトップへ戻ってご利用いただけます。
                    </div>
                </div> */}

                {/* ボタンエリア */}
                <div className="space-y-4">
                    <button
                        onClick={() => navigate("/querent_login")}
                        className="w-full py-2 rounded-xl bg-fuchsia-700 text-white font-semibold hover:bg-fuchsia-800 transition-colors text-sm"
                    >
                        ログインはこちら
                    </button>

                    <button
                        onClick={() => navigate("/")}
                        className="w-full py-2 rounded-xl bg-white/10 border border-white/20 text-white font-semibold hover:bg-white/15 transition-colors text-sm"
                    >
                        トップへ戻る
                    </button>
                </div>

                {/* 補助情報とかフッタ的な */}
                <div className="pt-2 border-t border-white/10 text-center">
                    <div className="text-[10px] text-white/40 leading-relaxed">
                        🔒 このページは相談者様専用の案内ページです。
                        <br />
                        占い師アカウントではログインできません。
                    </div>
                </div>
            </div>
        </div>
    );
}
